<?php //Standard call for dependencies?>
    </div>
    <!-- /#wrapper -->
<script type="text/javascript">
setTimeout(function(){window.location.reload(1)}, 301000);
</script>
    <script src="/vendor/jquery/jquery-1.12.4.js"></script>
    <script src="/vendor/jquery/jquery.min.js"></script>
    <script src="/vendor/datatables/js/dataTables.min.js"></script>
    <script src="/vendor/blackrock-digital/js/sb-admin-2.js"></script>
    <script src="/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="/vendor/fabapp/fabapp.js?=v8"></script>
    <script src="/vendor/metisMenu/metisMenu.min.js"></script>
    <script src="/vendor/morrisjs/morris.min.js"></script>
    <script src="/vendor/raphael/raphael.min.js"></script>
</body>
</html>