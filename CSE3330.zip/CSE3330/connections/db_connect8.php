<?php

    // Connecting to mysql database with Role 8
    $mysqli = new mysqli('localhost', 'class', 'class', 'food') or die(mysql_error());

?>